# WhatsApp by Botmaker

WhatsApp for Zendesk, by Botmaker

Integrate WhatsApp messaging for your business with Botmaker. 

Botmaker is an official WhatsApp Solution Provider. With Botmaker you can create a WhatsApp Business API account, that is already connected to Zendesk and the Botmaker platform.

You will be able to chat with clients from Zendesk, manage multiple agents with the same number and connect bots with artifical intelligence. You can also manage a handover protocol to transfer conversations with bots via WhatsApp to live agents.
